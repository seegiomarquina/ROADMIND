# RoadMind AI

Intelligent Road Scene Understanding and Hazard Detection.

## Overview

RoadMind AI is a computer vision prototype that uses a
pretrained YOLOv8 Nano model to identify road-related
objects in images.

It detects vehicles, pedestrians, bicycles, traffic lights,
stop signs and other objects.

The prototype also calculates a heuristic road-scene risk
score using detected object categories, bounding-box size,
vertical image position and model confidence.

## Technologies

- Python
- YOLOv8
- OpenCV
- NumPy
- Pandas
- Matplotlib
- Computer Vision

## Features

- Road object detection
- Bounding-box visualization
- Object classification
- Heuristic hazard scoring
- Scene-level risk reports
- CSV export
- Statistical visualizations

## Model

YOLOv8 Nano pretrained on COCO.

## Risk Scoring

The risk score is a prototype heuristic. It is NOT a
calibrated collision probability or a validated safety metric.

The model analyzes individual images and does not predict
future vehicle movement or collision events.

## Evaluation

Detection confidence is reported for each detection.
Actual precision, recall and mAP require a separate
ground-truth annotated test dataset.

## Execution

Open the notebook in Google Colab and run the cells.

## Limitations

- Static image analysis only.
- No vehicle tracking.
- No temporal collision prediction.
- Risk scores are not safety-certified.
- COCO training data is not specifically optimized
  for every road environment.

## Future Improvements

- Video-based vehicle tracking
- Object distance estimation
- Lane detection
- Traffic sign recognition
- Temporal hazard prediction
- Ground-truth evaluation with road datasets

## Disclaimer

This is an educational research prototype and should
not be used as a real vehicle safety system.